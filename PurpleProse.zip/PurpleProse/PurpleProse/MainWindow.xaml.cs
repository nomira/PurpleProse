﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using StoryPlanner;

namespace PurpleProse
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        TreeViewItem mainCharList;
        TreeViewItem secondaryCharList;
        TreeViewItem otherCharList;

        public MainWindow()
        {
            InitializeComponent();
            
            mainCharList = new TreeViewItem() { Title = "Main Characters" };
            secondaryCharList = new TreeViewItem() { Title = "Secondary Characters" };
            otherCharList = new TreeViewItem() { Title = "Other Characters" };

            mainCharList.Items.Add(new StoryPlanner.Character("Jim Bob", null, null, null, 2, null, null, null, null, null, null));
            mainCharList.Items.Add(new StoryPlanner.Character("Jimbo", null, null, null, 2, null, null, null, null, null, null));
            mainCharList.Items.Add(new StoryPlanner.Character("Jimmmy", null, null, null, 2, null, null, null, null, null, null));
            secondaryCharList.Items.Add(new StoryPlanner.Character("Jim", null, null, null, 2, null, null, null, null, null, null));
            otherCharList.Items.Add(new StoryPlanner.Character("Joe", null, null, null, 2, null, null, null, null, null, null));
            otherCharList.Items.Add(new StoryPlanner.Character("Joe", null, null, null, 2, null, null, null, null, null, null));

            TreeCharData.Items.Add(mainCharList);
            TreeCharData.Items.Add(secondaryCharList);
            TreeCharData.Items.Add(otherCharList);
        }

        private void SetCharData(StoryPlanner.Character ch)
        {
            charName.Text = ch.Name;
            charAge.Text = ch.charAge.ToString();

        }

        private void menuNewChar_Click(object sender, RoutedEventArgs e)
        {
            EditCharacter ec = new EditCharacter(new StoryPlanner.Character());

            ec.ShowDialog();

            if(ec.DialogResult.HasValue && ec.DialogResult.Value)
            {
                StoryPlanner.Character newc = ec.SaveNewChar();

                mainCharList.Items.Add(newc);
            }
        }

        private void TreeCharData_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (TreeCharData.SelectedItem == null)
                return;

            string temp = TreeCharData.SelectedItem.ToString();

            StoryPlanner.Character ch;

            for(int i = 0; i < mainCharList.Items.Count; ++i)
            {
                if(mainCharList.Items[i].Name == temp)
                {
                    ch = (Character)mainCharList.Items[i];
                    SetCharData(ch);
                }
            }
        }
    }

    
}
