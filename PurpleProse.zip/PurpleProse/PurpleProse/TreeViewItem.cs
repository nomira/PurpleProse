﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

namespace PurpleProse
{
    public class TreeViewItem
    {
        public string Title { get; set; }
        public ObservableCollection<StoryPlanner.Object> Items { get; set; }

        public TreeViewItem()
        {
            this.Items = new ObservableCollection<StoryPlanner.Object>();
        }
    }
}
