﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using StoryPlanner;

namespace PurpleProse
{
    /// <summary>
    /// Interaction logic for NewCharacter.xaml
    /// </summary>
    public partial class EditCharacter : Window
    {
        public EditCharacter(StoryPlanner.Character c)
        {
            InitializeComponent();

            if(c != null)
            {
                txtboxName.Text = c.Name;
                txtboxAge.Text = c.charAge.ToString();
                txtboxGender.Text = c.charGender;
                txtboxKind.Text = c.charKind;
                txtboxRole.Text = c.charRole;
            }

        }

        public StoryPlanner.Character SaveNewChar()
        {
            StoryPlanner.Character ret = new Character();

            ret.Name = txtboxName.Text;
            ret.charAge = Convert.ToInt32(txtboxAge.Text);
            ret.charGender = txtboxGender.Text;
            ret.charKind = txtboxKind.Text;
            ret.charRole = txtboxRole.Text;

            return ret;
        }

        public void EditExistingChar(ref StoryPlanner.Character existingChar)
        {
            existingChar.Name = txtboxName.Text;
            existingChar.charAge = Convert.ToInt32(txtboxAge.Text);
            existingChar.charGender = txtboxGender.Text;
            existingChar.charKind = txtboxKind.Text;
            existingChar.charRole = txtboxRole.Text;
        }
        
    }
}
